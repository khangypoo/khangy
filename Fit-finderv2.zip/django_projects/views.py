from django.shortcuts import render

from .models import Topic

def home(request):
    return render(request, 'django_projects/home.html')




# Create your views here.
def index(request):
  """The home page for Learning Log."""
  return render(request, 'django_projects/index.html')
  
def topics(request):
  """Show all topics."""
  topics = Topic.objects.order_by('date_added')
  context = {'topics': topics}
  return render(request, 'django_projects/topics.html', context)
  
def topic(request, topic_id):
  """Show a single topic and all its entries."""
  topic = Topic.objects.get(id=topic_id)
  entries = topic.entry_set.order_by('-date_added')
  context = {'topic': topic, 'entries': entries}
  return render(request, 'django_projects/topic.html', context)



import random

def generate_clothes(request):
    clothes_types = ['Shirt', 'Pants', 'Shoes']
    random_clothes = {clothes_type: random.choice(['Red', 'Blue', 'Green']) for clothes_type in clothes_types}
    return render(request, 'shop/random_clothes.html', {'random_clothes': random_clothes})

def second_page(request):
  return render(request, 'django_projects/about.html')
def third_page(request):
  return render(request, 'index.html')