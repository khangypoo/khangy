from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),
    path('generate-clothes/', views.generate_clothes, name='generate_clothes'),
  path('about.html/',views.second_page, name='about'),
  path('index.html/',views.third_page, name='gallery')
]